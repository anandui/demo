﻿'use strict';

angular.module('Map')

.controller('mapController',
    ['$scope',
    function ($scope) {
		//$scope.maps = false;
		$scope.mapclick = function (){
      angular.element('body').addClass("alpha");
			//$scope.maps = true;
			if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (p) {
        var LatLng = new google.maps.LatLng(p.coords.latitude, p.coords.longitude);
        var mapOptions = {
            center: LatLng,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
        
		var infowindow = new google.maps.InfoWindow();
		var service = new google.maps.places.PlacesService(map);
        service.nearbySearch({
          location: LatLng,
          radius: 5000,
          type: ['store'],
		  keyword : 'dell'
        }, callback);
		function callback(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
          for (var i = 0; i < results.length; i++) {
            createMarker(results[i]);
          }
        }
		}
		function createMarker(place) {
        var placeLoc = place.geometry.location;
        var marker = new google.maps.Marker({
          map: map,
          position: place.geometry.location
        });
		console.log(place);
        google.maps.event.addListener(marker, 'click', function() {
          infowindow.setContent('<div><strong>' + place.name + '</strong><br>' +
                'Address: ' + place.vicinity + '</div>');
              infowindow.open(map, this);
        });
		}
    });
} else {
    alert('Geo Location feature is not supported in this browser.');
}
		}
			
    }]);