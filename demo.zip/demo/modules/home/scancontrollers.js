﻿'use strict';

angular.module('Scan')

.controller('scanController',
    ['$scope',
    function ($scope) {
		//$scope.maps = false;
	 angular.element('body').addClass("alpha");
			
    }]);