'use strict';

angular.module('Sidebar')

.controller('FooterController',
    ['$scope', '$rootScope', '$location', 'AuthenticationService',
    function ($scope, $rootScope, $location, AuthenticationService) {

}]);