﻿'use strict';

angular.module('Home')

.controller('HomeController',
    ['$scope','$cookieStore','$rootScope',
    function ($scope,$cookieStore,$rootScope) {

      $scope.home = function () {
    	 angular.element('body').addClass("alpha");
    	var usernames = $cookieStore.get('globals');
    	$rootScope.currentuser = usernames.currentUser.username;
      };
    $scope.mapmenu = function () {
    	angular.element('body').removeClass("active");
    };
    $scope.logout = function () {
    	angular.element('body').removeClass("active");
    };
	$scope.sidebaropen = function () {
		 angular.element('body').addClass("active");
	};
    $scope.closeNav = function (){
    	angular.element('body').removeClass("active");
    };
    $scope.sidebar = function () {

    };

    }]);