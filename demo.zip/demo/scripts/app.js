﻿'use strict';

// declare modules
angular.module('Authentication', []);
angular.module('Home', []);
angular.module('Sidebar', []);
angular.module('Map', []);
angular.module('Scan', []);


angular.module('BasicHttpAuthExample', [
    'Authentication',
    'Home',
    'Scan',
    'Map',
    'Sidebar',
    'ngRoute',
    'ngCookies'
])

.config(['$routeProvider', function ($routeProvider) {

    $routeProvider
        .when('/login', {
            controller: 'LoginController',
            templateUrl: 'modules/authentication/views/login.html'
        })

        .when('/home', {
            controller: 'HomeController',
            templateUrl: 'modules/home/views/home.html'
        })
        .when('/map', {
            controller: 'mapController',
            templateUrl: 'modules/home/views/map.html'
        })
        .when('/scan', {
            controller: 'scanController',
            templateUrl: 'modules/home/views/scan.html'
        })

        .otherwise({ redirectTo: '/login' });
}])


.directive('demoHeader', function() {
    return {
        restrict: 'E',
        scope: true,
    transclude : false,
    controller: 'HomeController',
        templateUrl: 
            'modules/header.html'
        };
})
.directive("sideBar", function() {
  return {
    restrict: 'E',
    templateUrl: 'modules/footer.html',
    scope: true,
    transclude : false,
    controller: 'HomeController'
  };
})
.run(['$rootScope', '$location', '$cookieStore', '$http',
    function ($rootScope, $location, $cookieStore, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in
            if ($location.path() !== '/login' && !$rootScope.globals.currentUser) {
                $location.path('/login');
            }
        });
    }]);
